//Henry McGee
//CPSC 2310 Section 1
//Assignment 2
//Due July 16
#ifndef HELPERFUNCTION_H
#define HELPERFUNCTION_H
#include <iostream>

//adding two binary numbers
//int* for passing an array
int addbinary(int, int*, int*);
//shifting product right
int shiftRight(int*, int*, int);
//converts binary to decimal
int convertToDecimal(int*, int*);

#endif
